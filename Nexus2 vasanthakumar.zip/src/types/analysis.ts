export type SentimentType = 'positive' | 'neutral' | 'negative';

export interface Topic {
  word: string;
  frequency: number;
}

export interface AnalysisResult {
  sentiment: SentimentType;
  sentimentScore: number;
  topics: Topic[];
  summary: string[];
  wordCount: number;
}