import { Hash, Flame } from 'lucide-react';

interface Topic {
  word: string;
  count: number;
  percentage: number;
}

interface TopicWordCloudProps {
  topics?: Topic[];
}

export function TopicWordCloud({ topics = [] }: TopicWordCloudProps) {
  const getFontSize = (percentage: number) => {
    if (percentage > 5) return 'text-4xl';
    if (percentage > 3) return 'text-3xl';
    if (percentage > 2) return 'text-2xl';
    if (percentage > 1) return 'text-xl';
    return 'text-lg';
  };

  const getColor = (index: number) => {
    const colors = [
      'text-orange-600',
      'text-rose-600',
      'text-amber-600',
      'text-pink-600',
      'text-red-600',
      'text-orange-700',
      'text-rose-700',
      'text-amber-700'
    ];
    return colors[index % colors.length];
  };

  if (!topics || topics.length === 0) {
    return (
      <div className="text-center py-12">
        <Hash className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h3 className="text-xl font-bold text-gray-800 mb-2">No Topics Found</h3>
        <p className="text-gray-600">Add more text to discover key topics</p>
      </div>
    );
  }

  return (
    <div className="text-center">
      <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center justify-center">
        <Flame className="w-6 h-6 mr-2 text-orange-500" />
        Key Topics
      </h3>
      
      <div className="flex flex-wrap gap-3 justify-center items-center min-h-[200px] p-6 bg-gradient-to-br from-orange-50 to-rose-50 rounded-2xl border border-orange-100">
        {topics.map((topic, index) => (
          <div
            key={topic.word}
            className={`${getFontSize(topic.percentage)} ${getColor(index)} font-bold transition-all duration-300 hover:scale-110 cursor-default`}
          >
            {topic.word}
          </div>
        ))}
      </div>
      
      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="p-3 bg-orange-100 rounded-xl border border-orange-200">
          <p className="text-orange-700 text-sm font-medium">Total Topics</p>
          <p className="text-gray-800 text-xl font-bold">{topics.length}</p>
        </div>
        <div className="p-3 bg-rose-100 rounded-xl border border-rose-200">
          <p className="text-rose-700 text-sm font-medium">Top Topic</p>
          <p className="text-gray-800 text-xl font-bold">{topics[0]?.word || 'N/A'}</p>
        </div>
      </div>
    </div>
  );
}