import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { FileText, Hash, Type, Clock, BookOpen, TrendingUp, Target, Zap } from 'lucide-react';
import { AnalysisResult } from '../utils/analyzeText';

interface StatisticsPanelProps {
  analysis?: AnalysisResult;
}

export function StatisticsPanel({ analysis }: StatisticsPanelProps) {
  const statistics = analysis?.statistics || {
    wordCount: 0,
    letterCount: 0,
    characterCount: 0,
    sentenceCount: 0,
    paragraphCount: 0,
    averageWordLength: 0,
    averageSentenceLength: 0,
    readingTime: 0
  };

  const wordFrequency = analysis?.wordFrequency || [];
  const readability = analysis?.readability || { score: 0, level: 'Easy' as const };

  const barChartData = [
    { name: 'Words', value: statistics.wordCount, color: '#FB923C' },
    { name: 'Letters', value: statistics.letterCount, color: '#10B981' },
    { name: 'Characters', value: statistics.characterCount, color: '#F59E0B' },
    { name: 'Sentences', value: statistics.sentenceCount, color: '#F87171' },
    { name: 'Paragraphs', value: statistics.paragraphCount, color: '#FB7185' }
  ];

  const pieChartData = wordFrequency.slice(0, 5).map(item => ({
    name: item.word,
    value: item.count
  }));

  const lineChartData = [
    { metric: 'Word Length', value: statistics.averageWordLength },
    { metric: 'Sentence Length', value: statistics.averageSentenceLength },
    { metric: 'Readability', value: readability.score / 10 }
  ];

  const COLORS = ['#FB923C', '#FB7185', '#F97316', '#F59E0B', '#FBBF24'];

  const StatCard = ({ icon: Icon, title, value, unit, bgColor }: any) => (
    <div className={`p-6 rounded-2xl ${bgColor} border border-orange-100 hover:shadow-lg transition-all duration-300 hover:transform hover:scale-105`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-700 text-sm font-medium">{title}</p>
          <p className="text-gray-900 text-3xl font-bold mt-1">
            {value.toLocaleString()}
            {unit && <span className="text-lg font-normal text-gray-600 ml-1">{unit}</span>}
          </p>
        </div>
        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
          <Icon className="w-6 h-6 text-orange-600" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Detailed Statistics</h3>
        <p className="text-gray-600">Comprehensive text metrics and analysis</p>
      </div>

      {/* Key Statistics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          icon={FileText}
          title="Total Words"
          value={statistics.wordCount}
          bgColor="bg-orange-50"
        />
        <StatCard
          icon={Type}
          title="Total Letters"
          value={statistics.letterCount}
          bgColor="bg-emerald-50"
        />
        <StatCard
          icon={Hash}
          title="Characters"
          value={statistics.characterCount}
          bgColor="bg-amber-50"
        />
        <StatCard
          icon={Clock}
          title="Reading Time"
          value={statistics.readingTime}
          unit="min"
          bgColor="bg-rose-50"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Bar Chart */}
        <div className="p-6 bg-white rounded-2xl border border-orange-100">
          <h4 className="text-lg font-semibold text-gray-800 mb-6 flex items-center">
            <BookOpen className="w-5 h-5 mr-2 text-orange-500" />
            Text Composition
          </h4>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={barChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="name" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #fed7aa', 
                  borderRadius: '12px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                {barChartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie Chart */}
        <div className="p-6 bg-white rounded-2xl border border-orange-100">
          <h4 className="text-lg font-semibold text-gray-800 mb-6 flex items-center">
            <Target className="w-5 h-5 mr-2 text-rose-500" />
            Word Frequency
          </h4>
          {pieChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    border: '1px solid #fecaca', 
                    borderRadius: '12px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-gray-500">
              <div className="text-center">
                <Target className="w-12 h-12 mx-auto mb-4" />
                <p>No frequency data available</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Additional Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Line Chart */}
        <div className="p-6 bg-white rounded-2xl border border-orange-100">
          <h4 className="text-lg font-semibold text-gray-800 mb-6 flex items-center">
            <Zap className="w-5 h-5 mr-2 text-amber-500" />
            Reading Metrics
          </h4>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={lineChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="metric" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #fed7aa', 
                  borderRadius: '12px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="#FB923C" 
                strokeWidth={3}
                dot={{ fill: '#FB923C', r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Detailed Statistics */}
        <div className="p-6 bg-white rounded-2xl border border-orange-100">
          <h4 className="text-lg font-semibold text-gray-800 mb-6">Analysis Details</h4>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-orange-50 rounded-xl">
              <span className="text-gray-700">Avg Word Length</span>
              <span className="text-gray-900 font-bold">{statistics.averageWordLength} chars</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-rose-50 rounded-xl">
              <span className="text-gray-700">Avg Sentence Length</span>
              <span className="text-gray-900 font-bold">{statistics.averageSentenceLength} words</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-xl">
              <span className="text-gray-700">Readability</span>
              <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                readability.level === 'Easy' ? 'bg-emerald-200 text-emerald-800' :
                readability.level === 'Moderate' ? 'bg-amber-200 text-amber-800' :
                'bg-red-200 text-red-800'
              }`}>
                {readability.level}
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-amber-50 rounded-xl">
              <span className="text-gray-700">Readability Score</span>
              <span className="text-gray-900 font-bold">{readability.score}/100</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}