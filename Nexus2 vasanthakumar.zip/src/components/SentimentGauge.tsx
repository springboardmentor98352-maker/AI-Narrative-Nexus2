import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface SentimentGaugeProps {
  sentiment?: {
    score: number;
    label: 'Positive' | 'Neutral' | 'Negative';
    confidence: number;
  };
}

export function SentimentGauge({ sentiment }: SentimentGaugeProps) {
  const score = sentiment?.score ?? 0;
  const label = sentiment?.label ?? 'Neutral';
  const confidence = sentiment?.confidence ?? 0;

  const percentage = Math.abs(score) * 100;

  const getSentimentData = () => {
    if (label === 'Positive') {
      return {
        color: 'from-emerald-400 to-green-600',
        bgColor: 'bg-emerald-100',
        borderColor: 'border-emerald-300',
        textColor: 'text-emerald-700',
        icon: TrendingUp,
        emoji: '😊'
      };
    }
    if (label === 'Negative') {
      return {
        color: 'from-rose-400 to-red-600',
        bgColor: 'bg-rose-100',
        borderColor: 'border-rose-300',
        textColor: 'text-rose-700',
        icon: TrendingDown,
        emoji: '😔'
      };
    }
    return {
      color: 'from-gray-400 to-slate-600',
      bgColor: 'bg-gray-100',
      borderColor: 'border-gray-300',
      textColor: 'text-gray-700',
      icon: Minus,
      emoji: '😐'
    };
  };

  const sentimentData = getSentimentData();
  const Icon = sentimentData.icon;

  return (
    <div className="text-center">
      <h3 className="text-xl font-bold text-gray-800 mb-6">Sentiment Analysis</h3>
      
      {/* Circular Progress */}
      <div className="relative w-48 h-48 mx-auto mb-6">
        <div className="absolute inset-0 rounded-full border-8 border-gray-200"></div>
        <div 
          className={`absolute inset-0 rounded-full border-8 border-transparent border-t-current ${sentimentData.textColor} transform transition-all duration-1000 ease-out`}
          style={{ 
            transform: `rotate(${percentage * 3.6}deg)`,
            borderTopColor: 'currentColor'
          }}
        ></div>
        
        {/* Center Content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-5xl mb-2">{sentimentData.emoji}</div>
          <p className={`text-2xl font-bold ${sentimentData.textColor}`}>
            {label}
          </p>
        </div>
      </div>

      {/* Score and Confidence */}
      <div className="space-y-4">
        <div className={`p-4 rounded-xl ${sentimentData.bgColor} ${sentimentData.borderColor} border`}>
          <div className="flex items-center justify-center space-x-2 mb-2">
            <Icon className={`w-5 h-5 ${sentimentData.textColor}`} />
            <span className="text-gray-700 font-medium">Sentiment Score</span>
          </div>
          <p className={`text-3xl font-bold ${sentimentData.textColor}`}>
            {score > 0 ? '+' : ''}{score.toFixed(2)}
          </p>
        </div>
        
        <div className="p-4 bg-orange-50 rounded-xl border border-orange-200">
          <p className="text-gray-700 text-sm mb-2">Confidence Level</p>
          <div className="flex items-center space-x-3">
            <div className="flex-1 bg-gray-200 rounded-full h-3">
              <div 
                className={`h-3 rounded-full bg-gradient-to-r ${sentimentData.color} transition-all duration-500`}
                style={{ width: `${confidence * 100}%` }}
              ></div>
            </div>
            <span className="text-gray-800 font-bold">{(confidence * 100).toFixed(0)}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}