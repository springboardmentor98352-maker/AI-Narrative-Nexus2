import { Quote, Lightbulb } from 'lucide-react';

interface SummaryCardProps {
  summary?: string[];
}

export function SummaryCard({ summary = [] }: SummaryCardProps) {
  if (!summary || summary.length === 0) {
    return (
      <div className="text-center py-12">
        <Lightbulb className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h3 className="text-xl font-bold text-gray-800 mb-2">No Insights Available</h3>
        <p className="text-gray-600">Provide more text to generate key insights</p>
      </div>
    );
  }

  return (
    <div className="text-center">
      <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center justify-center">
        <Lightbulb className="w-6 h-6 mr-2 text-amber-500" />
        Key Insights
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {summary.map((sentence, index) => (
          <div
            key={index}
            className="relative p-6 bg-gradient-to-br from-orange-50 to-rose-50 rounded-2xl border border-orange-200 hover:shadow-lg transition-all duration-300 hover:transform hover:scale-105"
          >
            <div className="absolute top-3 left-3">
              <Quote className="w-5 h-5 text-orange-400" />
            </div>
            
            <p className="text-gray-800 leading-relaxed text-sm font-medium mt-4">
              {sentence}
            </p>
            
            <div className="absolute bottom-3 right-3">
              <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-rose-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">{index + 1}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8 p-4 bg-orange-50 rounded-xl border border-orange-200">
        <p className="text-gray-700 text-sm flex items-center justify-center">
          <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
          AI-powered extractive summarization
        </p>
      </div>
    </div>
  );
}