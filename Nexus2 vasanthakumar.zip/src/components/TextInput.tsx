import { Button } from '../components/ui/button';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { Upload, X, FileText, Sparkles, Loader2 } from 'lucide-react';

interface TextInputProps {
  value: string;
  onChange: (value: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
  onFileUpload: (file: File) => Promise<void>;
  uploadedFileName: string | null;
  onReset: () => void;
}

export function TextInput({
  value,
  onChange,
  onAnalyze,
  isAnalyzing,
  onFileUpload,
  uploadedFileName,
  onReset
}: TextInputProps) {
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await onFileUpload(file);
    }
  };

  const characterCount = value.length;
  const maxCharacters = 100000; // Increased from 10,000 to 100,000
  const isNearLimit = characterCount > maxCharacters * 0.9;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Transform Your Text</h2>
        <p className="text-gray-600">Paste or upload your content to discover powerful insights</p>
      </div>

      {/* File Upload Area */}
      <div className="relative">
        <input
          type="file"
          id="file-upload"
          accept=".txt,.csv,.docx,.pdf"
          onChange={handleFileChange}
          className="hidden"
        />
        <label
          htmlFor="file-upload"
          className="flex items-center justify-center w-full p-6 border-2 border-dashed border-orange-300 rounded-2xl cursor-pointer bg-gradient-to-r from-orange-50 to-rose-50 hover:from-orange-100 hover:to-rose-100 transition-all duration-300 group"
        >
          <div className="text-center">
            <Upload className="w-8 h-8 mx-auto mb-2 text-orange-500 group-hover:text-orange-600 transition-colors" />
            <p className="text-orange-700 font-medium">Drop files here or click to upload</p>
            <p className="text-gray-500 text-sm mt-1">TXT, CSV, DOCX, PDF supported</p>
          </div>
        </label>
      </div>

      {/* Uploaded File Display */}
      {uploadedFileName && (
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-orange-100 to-rose-100 rounded-2xl border border-orange-200">
          <div className="flex items-center space-x-3">
            <FileText className="w-5 h-5 text-orange-600" />
            <span className="text-orange-800 font-medium">{uploadedFileName}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onReset}
            className="text-gray-600 hover:text-orange-600 hover:bg-orange-50"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Text Input */}
      <div className="space-y-3">
        <Label htmlFor="text-input" className="text-orange-700 font-semibold">
          Your Content
        </Label>
        <Textarea
          id="text-input"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Paste your text here... Share articles, reviews, reports, or any content you'd like to analyze."
          className="min-h-[300px] bg-white border-orange-200 text-gray-800 placeholder-gray-500 focus:border-orange-400 focus:ring-orange-200 resize-none rounded-xl"
          maxLength={maxCharacters}
        />
        
        {/* Character Counter */}
        <div className="flex items-center justify-between">
          <span className={`text-sm ${isNearLimit ? 'text-rose-600 font-medium' : 'text-gray-600'}`}>
            {characterCount.toLocaleString()} / {maxCharacters.toLocaleString()} characters
          </span>
          {isNearLimit && (
            <span className="text-sm text-rose-600 animate-pulse">
              ⚠️ Almost at limit
            </span>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-4">
        <Button
          onClick={onAnalyze}
          disabled={!value.trim() || isAnalyzing}
          className="flex-1 bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white font-semibold py-4 px-8 rounded-xl shadow-lg transform transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 mr-2" />
              Analyze Text
            </>
          )}
        </Button>
        
        {value && (
          <Button
            variant="outline"
            onClick={onReset}
            className="px-8 py-4 rounded-xl border-orange-200 text-orange-600 hover:bg-orange-50 transition-all duration-300"
          >
            Clear
          </Button>
        )}
      </div>
    </div>
  );
}