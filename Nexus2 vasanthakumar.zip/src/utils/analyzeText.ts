export interface AnalysisResult {
  sentiment: {
    score: number;
    label: 'Positive' | 'Neutral' | 'Negative';
    confidence: number;
  };
  topics: Array<{
    word: string;
    count: number;
    percentage: number;
  }>;
  summary: string[];
  statistics: {
    wordCount: number;
    letterCount: number;
    characterCount: number;
    sentenceCount: number;
    paragraphCount: number;
    averageWordLength: number;
    averageSentenceLength: number;
    readingTime: number; // in minutes
  };
  wordFrequency: Array<{
    word: string;
    count: number;
    category: 'common' | 'moderate' | 'frequent';
  }>;
  readability: {
    score: number;
    level: 'Easy' | 'Moderate' | 'Difficult';
  };
}

// Common stop words to filter out
const stopWords = new Set([
  'the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'i',
  'it', 'for', 'not', 'on', 'with', 'he', 'as', 'you', 'do', 'at',
  'this', 'but', 'his', 'by', 'from', 'they', 'we', 'say', 'her', 'she',
  'or', 'an', 'will', 'my', 'one', 'all', 'would', 'there', 'their',
  'what', 'so', 'up', 'out', 'if', 'about', 'who', 'get', 'which', 'go',
  'me', 'when', 'make', 'can', 'like', 'time', 'no', 'just', 'him', 'know',
  'take', 'people', 'into', 'year', 'your', 'good', 'some', 'could', 'them',
  'see', 'other', 'than', 'then', 'now', 'look', 'only', 'come', 'its', 'over',
  'think', 'also', 'back', 'after', 'use', 'two', 'how', 'our', 'work',
  'first', 'well', 'way', 'even', 'new', 'want', 'because', 'any', 'these',
  'give', 'day', 'most', 'us', 'is', 'was', 'are', 'been', 'has', 'had',
  'were', 'said', 'did', 'having', 'may', 'am'
]);

// Sentiment word lists
const positiveWords = new Set([
  'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'awesome',
  'perfect', 'love', 'like', 'enjoy', 'happy', 'pleased', 'satisfied', 'delighted',
  'thrilled', 'excited', 'beautiful', 'brilliant', 'outstanding', 'superb',
  'magnificent', 'spectacular', 'impressive', 'remarkable', 'exceptional',
  'positive', 'best', 'better', 'nice', 'fine', 'cool', 'helpful', 'useful',
  'effective', 'successful', 'win', 'won', 'achieve', 'achieved', 'accomplish'
]);

const negativeWords = new Set([
  'bad', 'terrible', 'awful', 'horrible', 'disgusting', 'hate', 'dislike',
  'angry', 'frustrated', 'disappointed', 'sad', 'upset', 'annoyed', 'irritated',
  'worst', 'worse', 'poor', 'weak', 'fail', 'failed', 'failure', 'mistake',
  'error', 'problem', 'issue', 'difficult', 'hard', 'impossible', 'wrong',
  'negative', 'ugly', 'disgusting', 'nasty', 'unpleasant', 'uncomfortable',
  'painful', 'hurt', 'damage', 'destroy', 'broken', 'useless', 'worthless',
  'cancel', 'rejected', 'denied', 'lost', 'loss', 'lose', 'losing'
]);

export function analyzeText(text: string): AnalysisResult {
  // Clean and tokenize text
  const cleanText = text.toLowerCase().replace(/[^\w\s]/g, ' ').replace(/\s+/g, ' ').trim();
  const words = cleanText.split(' ').filter(word => word.length > 0);
  const filteredWords = words.filter(word => !stopWords.has(word));
  
  // Count letters (excluding spaces and punctuation)
  const letterCount = text.replace(/[^a-zA-Z]/g, '').length;
  const characterCount = text.length;
  
  // Count sentences
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const sentenceCount = sentences.length;
  
  // Count paragraphs
  const paragraphs = text.split(/\n\n+/).filter(p => p.trim().length > 0);
  const paragraphCount = paragraphs.length;
  
  // Calculate averages
  const averageWordLength = words.length > 0 ? letterCount / words.length : 0;
  const averageSentenceLength = sentenceCount > 0 ? words.length / sentenceCount : 0;
  
  // Estimate reading time (average 200 words per minute)
  const readingTime = Math.ceil(words.length / 200);
  
  // Sentiment analysis
  const positiveCount = filteredWords.filter(word => positiveWords.has(word)).length;
  const negativeCount = filteredWords.filter(word => negativeWords.has(word)).length;
  const sentimentScore = filteredWords.length > 0 
    ? (positiveCount - negativeCount) / filteredWords.length 
    : 0;
  
  let sentimentLabel: 'Positive' | 'Neutral' | 'Negative';
  let sentimentConfidence: number;
  
  if (sentimentScore > 0.05) {
    sentimentLabel = 'Positive';
    sentimentConfidence = Math.min(sentimentScore * 10, 1);
  } else if (sentimentScore < -0.05) {
    sentimentLabel = 'Negative';
    sentimentConfidence = Math.min(Math.abs(sentimentScore) * 10, 1);
  } else {
    sentimentLabel = 'Neutral';
    sentimentConfidence = 0.5;
  }
  
  // Topic modeling (word frequency)
  const wordFreq: { [key: string]: number } = {};
  filteredWords.forEach(word => {
    wordFreq[word] = (wordFreq[word] || 0) + 1;
  });
  
  const topics = Object.entries(wordFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([word, count]) => ({
      word,
      count,
      percentage: (count / filteredWords.length) * 100
    }));
  
  // Word frequency for charts
  const allWordFreq = Object.entries(wordFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([word, count]) => {
      let category: 'common' | 'moderate' | 'frequent';
      if (count >= 5) category = 'frequent';
      else if (count >= 3) category = 'moderate';
      else category = 'common';
      
      return { word, count, category };
    });
  
  // Extractive summary
  const sentenceScores = sentences.map(sentence => {
    const sentenceWords = sentence.toLowerCase().split(/\s+/);
    const score = sentenceWords.filter(word => wordFreq[word]).length;
    return { sentence: sentence.trim(), score };
  });
  
  const summary = sentenceScores
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(item => item.sentence);
  
  // Readability score (simplified Flesch-Kincaid)
  const avgSentenceLength = sentenceCount > 0 ? words.length / sentenceCount : 0;
  const avgSyllables = words.reduce((acc, word) => acc + countSyllables(word), 0) / words.length;
  const readabilityScore = 206.835 - (1.015 * avgSentenceLength) - (84.6 * avgSyllables);
  
  let readabilityLevel: 'Easy' | 'Moderate' | 'Difficult';
  if (readabilityScore > 70) readabilityLevel = 'Easy';
  else if (readabilityScore > 50) readabilityLevel = 'Moderate';
  else readabilityLevel = 'Difficult';
  
  return {
    sentiment: {
      score: sentimentScore,
      label: sentimentLabel,
      confidence: sentimentConfidence
    },
    topics,
    summary,
    statistics: {
      wordCount: words.length,
      letterCount,
      characterCount,
      sentenceCount,
      paragraphCount,
      averageWordLength: Math.round(averageWordLength * 10) / 10,
      averageSentenceLength: Math.round(averageSentenceLength * 10) / 10,
      readingTime
    },
    wordFrequency: allWordFreq,
    readability: {
      score: Math.round(readabilityScore),
      level: readabilityLevel
    }
  };
}

function countSyllables(word: string): number {
  word = word.toLowerCase();
  if (word.length <= 3) return 1;
  word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '');
  word = word.replace(/^y/, '');
  const matches = word.match(/[aeiouy]{1,2}/g);
  return matches ? matches.length : 1;
}