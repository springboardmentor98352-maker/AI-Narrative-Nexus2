import { useState, useEffect } from 'react';
import { Button } from './components/ui/button';
import { TextInput } from './components/TextInput';
import { SentimentGauge } from './components/SentimentGauge';
import { TopicWordCloud } from './components/TopicWordCloud';
import { SummaryCard } from './components/SummaryCard';
import { StatisticsPanel } from './components/StatisticsPanel';
import { analyzeText, AnalysisResult } from './utils/analyzeText';
import { processFile } from './utils/fileProcessor';
import { Brain, BarChart3, Sparkles, FileText } from 'lucide-react';

function App() {
  const [text, setText] = useState('');
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'statistics'>('overview');

  const handleAnalyze = async () => {
    if (!text.trim()) return;
    
    setIsAnalyzing(true);
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const result = analyzeText(text);
    setAnalysis(result);
    setIsAnalyzing(false);
  };

  const handleFileUpload = async (file: File) => {
    try {
      const content = await processFile(file);
      setText(content);
      setUploadedFileName(file.name);
      setAnalysis(null);
    } catch (error) {
      console.error('File upload error:', error);
      throw error;
    }
  };

  const handleReset = () => {
    setText('');
    setAnalysis(null);
    setUploadedFileName(null);
    setActiveTab('overview');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-orange-50 to-amber-50">
      {/* Geometric Pattern Background */}
      <div className="fixed inset-0 opacity-30">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23f97316' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}></div>
      </div>

      {/* Header */}
      <header className="relative border-b border-orange-100 bg-white/80 backdrop-blur-sm shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-tr from-orange-400 to-rose-400 rounded-2xl transform rotate-6"></div>
                <div className="relative w-12 h-12 bg-gradient-to-tr from-orange-500 to-rose-500 rounded-2xl flex items-center justify-center shadow-lg">
                  <Brain className="w-7 h-7 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-rose-600 bg-clip-text text-transparent">
                  NarrativeNexus
                </h1>
                <p className="text-sm text-gray-600">Intelligent Text Analysis Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="px-4 py-2 bg-gradient-to-r from-orange-100 to-rose-100 rounded-full border border-orange-200">
                <span className="text-sm text-orange-700 font-medium">🚀 Lightning Fast</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Input Section */}
        <div className="relative mb-8">
          <div className="absolute inset-0 bg-gradient-to-r from-orange-100 to-rose-100 rounded-3xl transform -rotate-1"></div>
          <div className="relative bg-white rounded-3xl shadow-xl p-8 border border-orange-100">
            <TextInput
              value={text}
              onChange={setText}
              onAnalyze={handleAnalyze}
              isAnalyzing={isAnalyzing}
              onFileUpload={handleFileUpload}
              uploadedFileName={uploadedFileName}
              onReset={handleReset}
            />
          </div>
        </div>

        {/* Results Section */}
        {analysis && (
          <div className="space-y-8">
            {/* Tab Navigation */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-orange-100 to-rose-100 rounded-2xl transform rotate-1"></div>
              <div className="relative bg-white rounded-2xl shadow-lg p-2">
                <div className="flex space-x-2">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`flex-1 flex items-center justify-center space-x-2 px-6 py-4 rounded-xl font-semibold transition-all duration-300 ${
                      activeTab === 'overview'
                        ? 'bg-gradient-to-r from-orange-500 to-rose-500 text-white shadow-lg transform scale-105'
                        : 'text-gray-600 hover:text-orange-600 hover:bg-orange-50'
                    }`}
                  >
                    <Sparkles className="w-5 h-5" />
                    <span>Insights</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('statistics')}
                    className={`flex-1 flex items-center justify-center space-x-2 px-6 py-4 rounded-xl font-semibold transition-all duration-300 ${
                      activeTab === 'statistics'
                        ? 'bg-gradient-to-r from-orange-500 to-rose-500 text-white shadow-lg transform scale-105'
                        : 'text-gray-600 hover:text-orange-600 hover:bg-orange-50'
                    }`}
                  >
                    <BarChart3 className="w-5 h-5" />
                    <span>Statistics</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Tab Content */}
            <div className="animate-slideUp">
              {activeTab === 'overview' ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Sentiment Gauge */}
                  <div className="group">
                    <div className="bg-white rounded-3xl shadow-xl p-8 border border-orange-100 transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                      <SentimentGauge sentiment={analysis.sentiment} />
                    </div>
                  </div>

                  {/* Topic Word Cloud */}
                  <div className="group">
                    <div className="bg-white rounded-3xl shadow-xl p-8 border border-orange-100 transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                      <TopicWordCloud topics={analysis.topics} />
                    </div>
                  </div>

                  {/* Summary Card */}
                  <div className="group lg:col-span-2">
                    <div className="bg-white rounded-3xl shadow-xl p-8 border border-orange-100 transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                      <SummaryCard summary={analysis.summary} />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="group">
                  <div className="bg-white rounded-3xl shadow-xl p-8 border border-orange-100 transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                    <StatisticsPanel analysis={analysis} />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <footer className="relative mt-20 py-8 border-t border-orange-100">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <FileText className="w-5 h-5 text-orange-500" />
              <span className="text-orange-600 font-semibold">Privacy-First Analysis</span>
            </div>
            <p className="text-gray-600 text-sm">All processing happens locally in your browser</p>
            <p className="text-gray-500 text-xs mt-2">© 2024 NarrativeNexus • Smart Text Intelligence</p>
          </div>
        </footer>
      </main>

      <style jsx>{`
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-slideUp {
          animation: slideUp 0.6s ease-out;
        }
      `}</style>
    </div>
  );
}

export default App;